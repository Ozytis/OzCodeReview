﻿"use strict";

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

window.ozytis = window.ozytis || {};

ozytis.BlockEmbed = ozytis.BlockEmbed || Quill["import"]('blots/embed');

var MergeBlot = (function (_ozytis$BlockEmbed) {
    _inherits(MergeBlot, _ozytis$BlockEmbed);

    function MergeBlot() {
        _classCallCheck(this, MergeBlot);

        _get(Object.getPrototypeOf(MergeBlot.prototype), "constructor", this).apply(this, arguments);
    }

    _createClass(MergeBlot, null, [{
        key: "create",
        value: function create(value) {

            var node = _get(Object.getPrototypeOf(MergeBlot), "create", this).call(this);
            node.innerText = value.display;
            node.setAttribute("data-display", value.display);
            node.setAttribute("data-var", value.varName);
            node.className = "merge-var";
            node.setAttribute("contenteditable", "false");

            return node;
        }
    }, {
        key: "value",
        value: function value(node) {
            return {
                display: node.getAttribute('data-display'),
                varName: node.getAttribute('data-var')
            };
        }
    }]);

    return MergeBlot;
})(ozytis.BlockEmbed);

MergeBlot.className = "merge-var";
MergeBlot.blotName = "mergevar";
MergeBlot.tagName = "span";

Quill.register(MergeBlot, true);

var Block = Quill["import"]('blots/block');
Block.tagName = 'div';
Quill.register(Block);

// configure Quill to use inline styles so the email's format properly
var DirectionAttribute = Quill["import"]('attributors/attribute/direction');
Quill.register(DirectionAttribute, true);

var AlignClass = Quill["import"]('attributors/class/align');
Quill.register(AlignClass, true);

var BackgroundClass = Quill["import"]('attributors/class/background');
Quill.register(BackgroundClass, true);

var ColorClass = Quill["import"]('attributors/class/color');
Quill.register(ColorClass, true);

var DirectionClass = Quill["import"]('attributors/class/direction');
Quill.register(DirectionClass, true);

var FontClass = Quill["import"]('attributors/class/font');
Quill.register(FontClass, true);

var SizeClass = Quill["import"]('attributors/class/size');
Quill.register(SizeClass, true);

var AlignStyle = Quill["import"]('attributors/style/align');
Quill.register(AlignStyle, true);

var BackgroundStyle = Quill["import"]('attributors/style/background');
Quill.register(BackgroundStyle, true);

var ColorStyle = Quill["import"]('attributors/style/color');
Quill.register(ColorStyle, true);

var DirectionStyle = Quill["import"]('attributors/style/direction');
Quill.register(DirectionStyle, true);

var FontStyle = Quill["import"]('attributors/style/font');
Quill.register(FontStyle, true);

var SizeStyle = Quill["import"]('attributors/style/size');
SizeStyle.whitelist = ['8px', '10px', '12px', '14px', '16px', '18px', '20px'];
Quill.register(SizeStyle, true);

ozytis.quillEditors = ozytis.quillEditors || [];

ozytis.quillDefaultToolBar = {
    container: [['bold', 'italic', 'underline', 'strike'], // toggled buttons
    ['blockquote', 'code-block'], [{ 'header': 1 }, { 'header': 2 }], // custom button values
    [{ 'list': 'ordered' }, { 'list': 'bullet' }], [{ 'script': 'sub' }, { 'script': 'super' }], // superscript/subscript
    [{ 'indent': '-1' }, { 'indent': '+1' }], // outdent/indent
    [{ 'direction': 'rtl' }], // text direction

    [{ 'size': ['8px', '10px', '12px', '14px', '16px', '18px', '20px'] }], // custom dropdown
    [{ 'header': [1, 2, 3, 4, 5, 6, false] }], [{ 'color': [] }, { 'background': [] }], // dropdown with defaults from theme
    [{ 'font': [] }], [{ 'align': [] }], ['link', 'image'], ['clean'] // remove formatting button
    ]
};

ozytis.initQuillEditor = function (element, elementId, options, dotNetHelper, content) {

    options.modules = options.modules || {};

    if (!options.modules.toolbar) {
        options.modules.toolbar = ozytis.quillDefaultToolBar;
    }

    var quill = new Quill(element, options);
    quill.dotNetHelper = dotNetHelper;

    ozytis.quillEditors[elementId] = quill;

    quill.on('text-change', function (delta, oldContent, source) {
        console.log("source ", source);
        if (source === Quill.sources.USER) {
            dotNetHelper.invokeMethodAsync("OnChange", quill.root.innerHTML);
        }
    });

    quill.on('selection-change', function (range, oldRange, source) {
        if (range) {
            quill.currentSelection = range;
        }
    });

    dotNetHelper.invokeMethodAsync("OnLoaded");
};

ozytis.setQuillEditorContent = function (editorId, content) {
    var editor = ozytis.quillEditors[editorId];

    if (!editor || editor.root.innerHTML === content) {
        return;
    }

    var delta = editor.clipboard.convert(content);
    editor.setContents(delta, Quill.sources.API);
};

ozytis.insertMergeVarIntoQuillEditor = function (editorId, varName, display) {
    var editor = ozytis.quillEditors[editorId];

    if (!editor) {
        return;
    }

    var range = editor.getSelection(true);

    editor.insertEmbed(range.index, 'mergevar', { varName: varName, display: display }, Quill.sources.USER);

    editor.dotNetHelper.invokeMethodAsync("OnChange", editor.root.innerHTML);
};

