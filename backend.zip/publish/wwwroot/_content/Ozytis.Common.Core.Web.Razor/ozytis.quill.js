﻿window.ozytis = window.ozytis || {};

ozytis.BlockEmbed = ozytis.BlockEmbed || Quill.import('blots/embed');

class MergeBlot extends ozytis.BlockEmbed {

    static create(value) {

        const node = super.create();
        node.innerText = value.display;
        node.setAttribute("data-display", value.display);
        node.setAttribute("data-var", value.varName);
        node.className = "merge-var";
        node.setAttribute("contenteditable", "false");

        return node;
    }

    static value(node) {
        return {
            display: node.getAttribute('data-display'),
            varName: node.getAttribute('data-var')
        };
    }
}

MergeBlot.className = "merge-var";
MergeBlot.blotName = "mergevar";
MergeBlot.tagName = "span";

Quill.register(MergeBlot, true);

var Block = Quill.import('blots/block');
Block.tagName = 'div';
Quill.register(Block);

// configure Quill to use inline styles so the email's format properly
var DirectionAttribute = Quill.import('attributors/attribute/direction');
Quill.register(DirectionAttribute, true);

var AlignClass = Quill.import('attributors/class/align');
Quill.register(AlignClass, true);

var BackgroundClass = Quill.import('attributors/class/background');
Quill.register(BackgroundClass, true);

var ColorClass = Quill.import('attributors/class/color');
Quill.register(ColorClass, true);

var DirectionClass = Quill.import('attributors/class/direction');
Quill.register(DirectionClass, true);

var FontClass = Quill.import('attributors/class/font');
Quill.register(FontClass, true);

var SizeClass = Quill.import('attributors/class/size');
Quill.register(SizeClass, true);

var AlignStyle = Quill.import('attributors/style/align');
Quill.register(AlignStyle, true);

var BackgroundStyle = Quill.import('attributors/style/background');
Quill.register(BackgroundStyle, true);

var ColorStyle = Quill.import('attributors/style/color');
Quill.register(ColorStyle, true);

var DirectionStyle = Quill.import('attributors/style/direction');
Quill.register(DirectionStyle, true);

var FontStyle = Quill.import('attributors/style/font');
Quill.register(FontStyle, true);

var SizeStyle = Quill.import('attributors/style/size');
SizeStyle.whitelist = ['8px', '10px', '12px', '14px', '16px', '18px', '20px'];
Quill.register(SizeStyle, true);

ozytis.quillEditors = ozytis.quillEditors || [];

ozytis.quillDefaultToolBar = {
    container: [
        ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
        ['blockquote', 'code-block'],

        [{ 'header': 1 }, { 'header': 2 }],               // custom button values
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
        [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
        [{ 'direction': 'rtl' }],                         // text direction

        [{ 'size': ['8px', '10px', '12px', '14px', '16px', '18px', '20px'] }],  // custom dropdown
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

        [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
        [{ 'font': [] }],
        [{ 'align': [] }],
        ['link', 'image'],
        ['clean']                                         // remove formatting button
    ]
};


ozytis.initQuillEditor = function (element, elementId, options, dotNetHelper, content) {

    options.modules = options.modules || {};

    if (!options.modules.toolbar) {
        options.modules.toolbar = ozytis.quillDefaultToolBar;
    }

    const quill = new Quill(element, options);
    quill.dotNetHelper = dotNetHelper;

    ozytis.quillEditors[elementId] = quill;

    quill.on('text-change', function (delta, oldContent, source) {
        console.log("source ", source);
        if (source === Quill.sources.USER) {
            dotNetHelper.invokeMethodAsync("OnChange", quill.root.innerHTML);
        }
    });

    quill.on('selection-change', function (range, oldRange, source) {
        if (range) {
            quill.currentSelection = range;
        }
    });

    dotNetHelper.invokeMethodAsync("OnLoaded");
}

ozytis.setQuillEditorContent = function (editorId, content) {
    var editor = ozytis.quillEditors[editorId];

    if (!editor || editor.root.innerHTML === content) {
        return;
    }

    const delta = editor.clipboard.convert(content);
    editor.setContents(delta, Quill.sources.API);
}

ozytis.insertMergeVarIntoQuillEditor = function (editorId, varName, display) {
    var editor = ozytis.quillEditors[editorId];

    if (!editor) {
        return;
    }

    let range = editor.getSelection(true);

    editor.insertEmbed(range.index, 'mergevar', { varName: varName, display: display }, Quill.sources.USER);

    editor.dotNetHelper.invokeMethodAsync("OnChange", editor.root.innerHTML);
}

