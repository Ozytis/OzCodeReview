﻿"use strict";
window.ozytis = window.ozytis || {};

// store list of what scripts we've loaded
ozytis.loaded = [];

/**
 * https://stackoverflow.com/questions/58976579/blazor-server-load-js-scripts-only-on-certain-pages-not-on-all
 * Charge une librairie si elle n'est pas déjà chargée
 * @param {any} scriptPath
 */
window.ozytis.loadScript = function (scriptPath) {

    // check list - if already loaded we can ignore
    if (ozytis.loaded[scriptPath]) {

        // return 'empty' promise
        return new Promise(function (resolve, reject) {
            resolve();
        });
    }

    return new Promise(function (resolve, reject) {
        // create JS library script element
        var script = document.createElement("script");
        script.src = scriptPath;
        script.type = "text/javascript";

        // flag as loading/loaded
        ozytis.loaded[scriptPath] = true;

        // if the script returns okay, return resolve
        script.onload = function () {

            caches.open("dynamic-cache").then(cache => {
                cache.add(scriptPath);
                resolve(scriptPath);
            });
        };

        // if it fails, return reject
        script.onerror = function () {
            reject(scriptPath);
        }

        // scripts will load at end of body
        document["body"].appendChild(script);
    });
}

window.ozytis.loadCss = function (cssPath) {

    // check list - if already loaded we can ignore
    if (ozytis.loaded[cssPath]) {

        // return 'empty' promise
        return new Promise(function (resolve, reject) {
            resolve();
        });
    }

    return new Promise(function (resolve, reject) {

        // create css library link element
        var link = document.createElement("link");
        link.href = cssPath;
        link.rel = "stylesheet";
        link.type = "text/css";

        // flag as loading/loaded
        ozytis.loaded[cssPath] = true;

        // if the script returns okay, return resolve
        link.onload = function () {
            resolve(cssPath);
        };

        // if it fails, return reject
        link.onerror = function () {
            console.log(cssPath + " load failed");
            reject(cssPath);
        }

        // css will load at end of head
        document["head"].appendChild(link);
    });
}




ozytis.downloadFile = function (url, fileName) {

    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = fileName;
    anchor.target = "_blank";

    document.body.appendChild(anchor);

    anchor.click();
    anchor.remove();
}

ozytis.clickOutsideListeners = ozytis.clickOutsideListeners || [];
ozytis.listenClickOutside = function (element, dotNetHelper, methodName) {

    ozytis.clickOutsideListeners[element] = function (e) {

        if (element.contains(e.target)) {
            return;
        }

        dotNetHelper.invokeMethod(methodName);
    };

    document.addEventListener("click", ozytis.clickOutsideListeners[element]);
}

ozytis.removeClickOutsideListener = function (element) {
    document.removeEventListener("click", ozytis.clickOutsideListeners[element]);
    delete ozytis.clickOutsideListeners[element];
}

ozytis.getItemInLocalStorage = function (key) {
    try {
        return JSON.parse(localStorage.getItem(key));
    } catch (e) {
        return "\"" + localStorage.getItem(key) + "\"";
    }
}

ozytis.perfectScrollBars = ozytis.perfectScrollBars || [];

ozytis.initPerfectScrollBar = function (element, options) {

    return new Promise(resolve => {

        const timer = setInterval(() => {

            if (window.PerfectScrollbar) {

                clearInterval(timer);

                const ps = new PerfectScrollbar(element, options);

                const observer = new MutationObserver(function (mutationsList, observer) {
                    if (element && ps) {
                        ps.update();
                    }
                });

                ozytis.perfectScrollBars.push(ps);
                observer.observe(element, { characterData: false, childList: true, attributes: false });
            }
        }, 200);
    });
}

ozytis.indexedDB = ozytis.indexedDB || {};

ozytis.indexedDB.initalize = function (config) {

    ozytis.indexedDB.config = config;

    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open(config.database, config.version);

        request.onsuccess = function (event) {
            resolve();
        }

        request.onerror = function (event) {
            reject(request.error);
        }

        request.onupgradeneeded = function (event) {
            const db = request.result;

            if (!db.objectStoreNames.contains(config.store)) {
                db.createObjectStore(config.store, { keyPath: 'key' });
            }

            resolve();
        };
    });
}

ozytis.indexedDB.setItem = function (key, value) {
    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open(ozytis.indexedDB.config.database, ozytis.indexedDB.config.version);

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction(ozytis.indexedDB.config.store, 'readwrite')

            const store = transaction.objectStore(ozytis.indexedDB.config.store);
            const insert = store.put({ value: value, key: key });

            insert.onsuccess = () => resolve();
            insert.onerror = () => reject(insert.error);
        }

        request.onerror = function () {
            reject(request.error);
        }
    });
}


ozytis.indexedDB.getItem = function (key) {

    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open(ozytis.indexedDB.config.database, ozytis.indexedDB.config.version);

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction(ozytis.indexedDB.config.store, 'readonly')

            const store = transaction.objectStore(ozytis.indexedDB.config.store);
            const read = store.get(key);

            read.onsuccess = () => {

                if (!read.result) {
                    resolve(null);
                    return;
                }

                resolve(read.result.value);
            }
            read.onerror = () => reject(read.error);
        }

        request.onerror = function () {
            reject(request.error);
        }
    });
}

ozytis.indexedDB.removeItem = function (key) {

    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open(ozytis.indexedDB.config.database, ozytis.indexedDB.config.version);

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction(ozytis.indexedDB.config.store, 'readwrite')

            const store = transaction.objectStore(ozytis.indexedDB.config.store);
            const read = store.delete(key);

            read.onsuccess = () => {

                resolve();
            }
            read.onerror = () => reject(read.error);
        }

        request.onerror = function () {
            reject(request.error);
        }
    });
}

ozytis.getCurrentLocation = function (options) {
    return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
            position => {

                resolve({
                    location: {
                        coords: {
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude,
                            altitude: position.coords.altitude,
                            altitudeAccuracy: position.coords.altitudeAccuracy,
                            accuracy: position.coords.accuracy,
                            heading: position.coords.heading,
                            speed: position.coords.speed
                        },
                        timestamp: position.timestamp
                    }
                });
            },
            error => {

                console.error("Geolocation error", error);

                resolve({
                    error: error
                });
            },
            options
        );
    });
}

ozytis.watchCurrentLocation = function (options, dotNetHelper) {

    navigator.geolocation.watchPosition(
        position => {

            var data = {
                location: {
                    coords: {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                        altitude: position.coords.altitude,
                        altitudeAccuracy: position.coords.altitudeAccuracy,
                        accuracy: position.coords.accuracy,
                        heading: position.coords.heading,
                        speed: position.coords.speed
                    },
                    timestamp: position.timestamp
                }
            };

            dotNetHelper.invokeMethodAsync('Invoke', data);
        },
        error => {

            console.error("Geolocation error", error);

            const data = {
                error: {
                    code: error.code,
                    message: error.message
                }
            };

            console.error("Geolocation error data", data);

            dotNetHelper.invokeMethodAsync('Invoke', data);
        },
        options
    );
}

ozytis.canShare = ozytis.canShare || function (data) {

    const shareData = {
        title: data.title,
        text: data.text,
        url: data.url
    };

    if (data.files && data.files.length > 0) {
        shareData.files = [];

        for (var fileIndex = 0; fileIndex < data.files.length; fileIndex++) {

            const bytes = atob(data.files[fileIndex].data);
            let n = bytes.length;
            const u8arr = new Uint8Array(n);

            while (n--) {
                u8arr[n] = bytes.charCodeAt(n);
            }

            shareData.files.push(new File([u8arr], data.files[fileIndex].name, { type: data.files[fileIndex].mimeType }));
        }
    }

    return navigator.canShare && navigator.canShare(shareData);
}

ozytis.share = ozytis.share || function (data) {

    return new Promise((resolve, reject) => {
        var shareData = {
            title: data.title,
            text: data.text,
            url: data.url
        };

        if (data.files && data.files.length > 0) {
            shareData.files = [];

            for (var fileIndex = 0; fileIndex < data.files.length; fileIndex++) {

                const bytes = atob(data.files[fileIndex].data);
                let n = bytes.length;
                const u8arr = new Uint8Array(n);

                while (n--) {
                    u8arr[n] = bytes.charCodeAt(n);
                }

                shareData.files.push(new File([u8arr], data.files[fileIndex].name, { type: data.files[fileIndex].mimeType }));
            }
        }

        navigator.share(shareData).then(() => resolve());
    });
}

window.ozytis.slider = window.ozytis.slider || {};

window.ozytis.slider.init = function (elementId, dotNetHelper, options) {

    window.ozytis.sliders = window.ozytis.sliders || {};

    return new Promise((resolve, reject) => {

        if (window.ozytis.sliders[elementId]) {
            resolve();
            return;
        }

        const mainDiv = document.getElementById(elementId);

        const svg = mainDiv.getElementsByTagName("svg")[0];
        const pt = svg.createSVGPoint();

        function cursorPoint(evt) {
            pt.x = evt.clientX; pt.y = evt.clientY;
            return pt.matrixTransform(svg.getScreenCTM().inverse());
        }

        window.ozytis.sliders[elementId] = {
            container: mainDiv,
            svg: svg,
            dotNetHelper: dotNetHelper,
            options: options
        }

        const cursor = svg.getElementsByClassName("oz-slider-cursor")[0];

        let cursorIsMoving = false;

        cursor.onmousedown = (e) => {
            cursorIsMoving = true;
        };

        svg.onmousemove = async (e) => {
            if (cursorIsMoving && options.isImmediateValue) {
                await dotNetHelper.invokeMethodAsync("OnChange", cursorPoint(e).x);
            }
        };

        svg.onmouseup = async (e) => {

            if (cursorIsMoving) {
                await dotNetHelper.invokeMethodAsync("OnChange", cursorPoint(e).x);
                cursorIsMoving = false;
            }
        };

        resolve();
        return;
    });
}

window.ozytis.dropDown = window.ozytis.dropDown || {};

window.ozytis.dropDown.init = function (elementId, dotNetHelper, options) {

    console.log("window.ozytis.dropDown.init", elementId, dotNetHelper, options);

    return new Promise((resolve) => {

        window.ozytis.dropDown.items = window.ozytis.dropDown.items || {};

        const item = {
            container: document.getElementById(elementId),
            input: document.getElementById(elementId).getElementsByTagName("input")[0],
            dotNetHelper: dotNetHelper,
            options: options || { options: [] },
            optionsContainer: null,
            showSuggestions: false
        }

        item.close = function () {
            item.optionsContainer.remove();
            item.showSuggestions = false;
            document.removeEventListener("mousemove", item.reposition);
            document.removeEventListener("click", item.clickOutsideListener);
            item.container.focus();
        };

        item.container.onclick = function (e) {

            if (item.showSuggestions) {
                item.close();
            } else {
                item.optionsContainer = document.createElement("div");
                item.optionsContainer.className = "options-container";

                item.optionsContainer.onclick = function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }

                console.log(JSON.parse(JSON.stringify(item.container)));

                const bounds = item.input.getBoundingClientRect();

                item.optionsContainer.style.position = "absolute";
                item.optionsContainer.style.top = bounds.top + bounds.height + "px";
                item.optionsContainer.style.left = bounds.left + "px";
                item.optionsContainer.style.width = bounds.width + "px";
                item.optionsContainer.style.zIndex = 1023;


                item.filterInput = document.createElement("input");
                item.filterInput.className = "options-filter";
                item.optionsContainer.appendChild(item.filterInput);

                item.filterInput.onkeydown = (function (e) {

                    if (item.filterTimeout) {
                        clearTimeout(item.filterTimeout);
                    }

                    item.filterTimeout = setTimeout(function () {
                        item.dotNetHelper.invokeMethodAsync("SetFilter", item.filterInput.value);
                    }, 500);

                });

                item.filterInput.onchange = (function (e) {
                    if (item.filterTimeout) {
                        clearTimeout(item.filterTimeout);
                    }

                    item.filterTimeout = setTimeout(function () {
                        item.dotNetHelper.invokeMethodAsync("SetFilter", item.filterInput.value);
                    }, 500);
                });

                const optionsHtmlList = document.createElement("ul");
                item.optionsContainer.appendChild(optionsHtmlList);
                item.optionsHtmlList = optionsHtmlList;
                item.optionsHtmlList.className = "options-list";

                item.rebuildOptions();

                // on fait coller la dropdown avec l'élément si celui-ci bouge
                document.addEventListener("mousemove", item.reposition);

                if (!item.clickOutsideListener) {

                    item.clickOutsideListener = function (e) {

                        if (item.optionsContainer.contains(e.target)) {
                            e.preventDefault();
                            e.stopPropagation();
                            return;
                        }

                        console.log("click outside");

                        if (item.showSuggestions) {
                            item.close();
                        }
                    };

                    console.log("adding listener");                  
                }

                setTimeout(function () {
                    document.addEventListener("click", item.clickOutsideListener);
                }, 200);

                item.showSuggestions = true;

                setTimeout(function () {
                    item.filterInput.focus();
                }, 200);

                document.body.appendChild(item.optionsContainer);
            }
        };

        item.reposition = function () {
            const bounds = item.input.getBoundingClientRect();
            item.optionsContainer.style.top = bounds.top + bounds.height + "px";
            item.optionsContainer.style.left = bounds.left + "px";
            item.optionsContainer.style.width = bounds.width + "px";
        }

        item.rebuildOptions = function () {
            item.optionsHtmlList.innerHTML = "";

            if (item.options.options && item.options.options.length > 0) {
                for (let option of item.options.options) {
                    const optionHtml = document.createElement("li");
                    optionHtml.textContent = option.label;

                    optionHtml.onclick = function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        item.dotNetHelper.invokeMethodAsync("ItemSelected", option.value);
                        item.close();
                    };

                    item.optionsHtmlList.appendChild(optionHtml);
                }
            }

            if (item.options.showMore === true) {
                const showMoreButton = document.createElement("div");
                showMoreButton.className = "show-more";
                showMoreButton.innerHTML = "Voir plus"
                item.optionsHtmlList.appendChild(showMoreButton);

                showMoreButton.onclick = function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    item.dotNetHelper.invokeMethodAsync("ShowMore");
                };
            }
        };

        window.ozytis.dropDown.items[elementId] = item;

        resolve();
        return;
    });

    window.ozytis.dropDown.items[elementId] = item;
}

window.ozytis.dropDown.refreshOptions = function (elementId, options) {

    console.log("window.ozytis.dropDown.refreshOptions", elementId, options, window.ozytis.dropDown);

    return new Promise((resolve, reject) => {

        const item = window.ozytis.dropDown.items[elementId];

        if (!item) {
            reject("select not found", elementId);
            return;
        }

        item.options.options = options.options;
        item.options.showMore = options.showMore;

        if (item.showSuggestions) {
            item.rebuildOptions();
        }

        resolve();
        return;
    });
}