﻿ozytis.grapesEditor = [];

ozytis.initGrapesJs = function (elementId, element, options, dotNetHelper, content) {

    const config = {
        // Indicate where to init the editor. You can also pass an HTMLElement
        container: element,
        // Get the content for the canvas directly from the element
        // As an alternative we could use: `components: '<h1>Hello World Component!</h1>'`,
        fromElement: false,
        components: content,
        // Size of the editor
        height: '300px',
        width: '100%',
        // Disable the storage manager for the moment
        storageManager: false,
        pluginsOpts: {
            'gjs-preset-newsletter': {
                modalTitleImport: 'Import template',
                // ... other options
            },
            'gjs-preset-webpage': {
                // options
            }
        },
        ozytisElementId: elementId
    };

    for (var option in options) {
        config[option] = options[option];
    }

    if (options.allowPicturesUpload) {
        config.assetManager = {
            upload: "/pictures",
            autoAdd: 1
        };
    }

    ozytis.grapesEditor[elementId] = grapesjs.init(config);

    dotNetHelper.invokeMethodAsync("OnLoaded");

    ozytis.grapesEditor[elementId].ozytis = {
        dotNetHelper: dotNetHelper,
        options: options,
        elementId: elementId
    };

    if (options.variables) {
        const blockManager = ozytis.grapesEditor[elementId].BlockManager;

        for (const variable of options.variables) {
            blockManager.add(variable.id, { label: variable.display, content: variable.html });
        }
    }

    ozytis.grapesEditor[elementId].on("update", function () {

        const elementId = this.config.ozytisElementId;
        const element = ozytis.grapesEditor[elementId];

        if (element.ozytis.options.plugins.indexOf("gjs-preset-newsletter") > -1) {
            element.ozytis.dotNetHelper.invokeMethodAsync("Update", element.runCommand("gjs-get-inlined-html"), null);
        } else {
            element.ozytis.dotNetHelper.invokeMethodAsync("Update", element.getHtml(), element.getCss());
        }
    });

    if (options.allowPicturesUpload) {
        fetch("/pictures/list").then(data => data.json()).then(json => {
            const assetManager = this.editor.AssetManager;
            for (const url of data.data) {
                assetManager.add({ src: url });
            }
        });
    }
}

ozytis.updateGrapeJsContent = function (elementId, content) {
    ozytis.grapesEditor[elementId].setComponents(content);
}

ozytis.removeGrapeJsBlocks = function (elementId, blockIds) {
    const blockManager = ozytis.grapesEditor[elementId].BlockManager;

    for (const blockId of blockIds) {
        blockManager.remove(blockId);
    }
}

ozytis.updateGrapeJsBlocks = function (elementId, blocks) {
    const blockManager = ozytis.grapesEditor[elementId].BlockManager;

    for (const variable of blocks) {
        blockManager.add(variable.id, { label: variable.display, content: variable.html });
    }
}

ozytis.callGrapeJs = function (elementId, functionName, args) {
    ozytis.grapesEditor[elementId][functionName](...args);
}